import { Check, Activity, Sparkles, CheckCircle2 } from "lucide-react";
import { Badge } from "../ui/Badge";
import { Button } from "../ui/Button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../ui/Card";
import { Container, Section, SectionHeading } from "../ui/Layout";
import { useDEXGateway, type PricingTier } from "../../context/DEXGatewayContext";
import { cn } from "../../utils/cn";

interface TierConfig {
  name: PricingTier;
  fee: string;
  unit: string;
  desc: string;
  features: string[];
  cta: string;
  popular: boolean;
}

const tiers: TierConfig[] = [
  {
    name: "Self",
    fee: "0%",
    unit: "performance fee",
    desc: "For sovereign individuals stacking their first sats.",
    features: ["Up to ₿1 deposited", "Conservative vaults", "Lightning deposits", "Community support"],
    cta: "Select 0% Take",
    popular: false,
  },
  {
    name: "Stacker",
    fee: "8%",
    unit: "on yield earned",
    desc: "For serious holders running multi-strategy positions.",
    features: [
      "Unlimited deposits",
      "All six vault strategies",
      "Auto de-risking engine",
      "Priority settlement lane",
      "Tax-ready exports",
    ],
    cta: "Apply 8% Take",
    popular: true,
  },
  {
    name: "Treasury",
    fee: "Custom",
    unit: "negotiated terms",
    desc: "For funds, miners, and corporate balance sheets.",
    features: [
      "Dedicated multisig quorum",
      "OTC entry & exit desk",
      "Proof-of-reserve reporting API",
      "Named risk analyst",
    ],
    cta: "Request Terms",
    popular: false,
  },
];

export function Pricing() {
  const { wallet, changePricingTier, openGateway, openTelemetry, telemetry } = useDEXGateway();

  const handleTierAction = (tierName: PricingTier) => {
    if (!wallet) {
      openGateway();
    } else {
      changePricingTier(tierName);
    }
  };

  return (
    <Section id="pricing" tone="surface">
      <Container className="relative">
        <SectionHeading
          eyebrow="Tiers"
          title="Pay only when you"
          accent="earn."
          description="No deposit fees. No withdrawal fees. No subscriptions. We take a cut of yield, never principal."
        />

        {/* Live Take Changes Banner directly linking to back-office analytics */}
        <div className="mt-8 flex justify-center">
          <button
            type="button"
            onClick={openTelemetry}
            className="group flex flex-wrap items-center gap-2.5 rounded-full border border-gold/40 bg-gold/5 px-4 py-2 font-mono text-xs text-gold shadow-[0_0_20px_rgb(255_214_0_/_0.15)] transition-all hover:border-gold hover:bg-gold/10"
          >
            <Activity className="h-3.5 w-3.5 animate-pulse text-gold" />
            <span>
              <strong>{telemetry.totalTakeChanges.toLocaleString()}</strong> fee take updates recorded in protocol back-office
            </span>
            <span className="hidden sm:inline text-white/40">|</span>
            <span className="hidden sm:inline text-stardust group-hover:text-white">
              View live ledger &amp; breakdown →
            </span>
          </button>
        </div>

        <div className="mt-12 grid items-center gap-8 md:grid-cols-3">
          {tiers.map((t) => {
            const isSelected = wallet?.tier === t.name;

            return (
              <Card
                key={t.name}
                variant={t.popular || isSelected ? "solid" : "subtle"}
                className={cn(
                  "flex h-full flex-col transition-all duration-300 relative",
                  isSelected
                    ? "z-20 border-gold ring-2 ring-gold/40 shadow-[0_0_45px_-5px_rgb(255_214_0_/_0.35)] md:scale-105"
                    : t.popular
                    ? "z-10 border-btc shadow-[0_0_40px_-10px_rgb(247_147_26_/_0.35)] md:scale-105"
                    : "opacity-85 hover:-translate-y-1 hover:border-btc/50 hover:opacity-100",
                )}
              >
                {isSelected ? (
                  <Badge
                    variant="gold"
                    size="sm"
                    className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-void shadow-[0_0_20px_rgb(255_214_0_/_0.6)] font-semibold"
                  >
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Your Active Fee Tier
                  </Badge>
                ) : t.popular ? (
                  <Badge
                    variant="btc"
                    size="sm"
                    className="absolute -top-3 left-1/2 -translate-x-1/2 bg-void shadow-[0_0_20px_-4px_rgb(247_147_26_/_0.8)]"
                  >
                    Most deposited
                  </Badge>
                ) : null}

                <CardHeader className="space-y-4 pt-8">
                  <div className="flex items-center justify-between">
                    <p className="font-mono text-[11px] uppercase tracking-widest text-btc">{t.name}</p>
                    <span className="font-mono text-[10px] text-stardust">
                      {telemetry.tierDistribution[t.name].toLocaleString()} active
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <CardTitle className="font-heading text-4xl font-bold tracking-tight">
                      {t.fee}
                    </CardTitle>
                    <span className="font-mono text-[11px] uppercase tracking-widest text-stardust">
                      {t.unit}
                    </span>
                  </div>
                  <CardDescription>{t.desc}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-3">
                    {t.features.map((f) => (
                      <li key={f} className="flex items-start gap-3">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-btc" />
                        <span className="text-sm leading-relaxed text-stardust">{f}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="pt-4">
                  <Button
                    onClick={() => handleTierAction(t.name)}
                    variant={isSelected ? "gold" : t.popular ? "primary" : "outline"}
                    className="w-full text-xs"
                  >
                    {isSelected ? (
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Current Take Applied
                      </span>
                    ) : wallet ? (
                      <span className="flex items-center gap-1.5">
                        <Sparkles className="h-3.5 w-3.5" />
                        Switch to {t.name} ({t.fee})
                      </span>
                    ) : (
                      t.cta
                    )}
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>

        {/* Back-office insight note */}
        <div className="mt-12 rounded-xl border border-white/10 bg-black/40 p-4 text-center">
          <p className="font-mono text-xs text-stardust">
            * All take rate changes are published to Bitcoin block receipts with zero lockup penalty.
            Current protocol take: <strong className="text-white">₿ {telemetry.totalFeeTakeBtc.toFixed(2)}</strong> from <strong className="text-gold">₿ {telemetry.totalYieldGeneratedBtc.toFixed(1)}</strong> gross earned.
          </p>
        </div>
      </Container>
    </Section>
  );
}
