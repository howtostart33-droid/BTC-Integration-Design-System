import { ArrowRight, Bitcoin, ShieldCheck, TrendingUp, Zap } from "lucide-react";
import { Badge, LiveDot } from "../ui/Badge";
import { ButtonLink } from "../ui/Button";
import { Card } from "../ui/Card";
import { Container, GlowBlob } from "../ui/Layout";

const trust = [
  { label: "Non-custodial", icon: ShieldCheck },
  { label: "Audited x4", icon: Zap },
  { label: "Proof of reserve", icon: Bitcoin },
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-void pb-20 pt-32 md:pb-28 md:pt-40">
      {/* Textured void: grid + ambient energy fields */}
      <div aria-hidden className="absolute inset-0 bg-grid-pattern" />
      <GlowBlob className="-left-24 top-10 h-[420px] w-[420px]" color="ember" />
      <GlowBlob className="-right-20 top-40 h-[480px] w-[480px]" color="gold" />

      <Container className="relative grid items-center gap-16 lg:grid-cols-[1.05fr_0.95fr]">
        {/* ---------------- Copy column ---------------- */}
        <div className="flex flex-col items-start gap-7">
          <Badge variant="gold" className="pl-3">
            <LiveDot />
            Mainnet live · Block 887,412
          </Badge>

          <h1 className="font-heading text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-5xl md:text-7xl">
            Put your bitcoin
            <br className="hidden sm:block" /> to <span className="text-gradient-btc">work.</span>
          </h1>

          <p className="max-w-xl text-base leading-relaxed text-stardust md:text-lg">
            Satstack is a non-custodial yield layer for BTC. Route sats into audited vaults,
            keep your keys, and settle every position on-chain with verifiable proofs.
          </p>

          <div className="flex w-full flex-col gap-4 sm:w-auto sm:flex-row sm:items-center">
            <ButtonLink href="#vaults" size="lg" className="w-full sm:w-auto">
              Launch app <ArrowRight className="h-4 w-4" />
            </ButtonLink>
            <ButtonLink href="#pricing" variant="outline" size="lg" className="w-full sm:w-auto">
              Pay Only When You Earn
            </ButtonLink>
          </div>

          <ul className="flex flex-wrap items-center gap-x-6 gap-y-3 pt-2">
            {trust.map((t) => (
              <li key={t.label} className="flex items-center gap-2">
                <t.icon className="h-4 w-4 text-btc" />
                <span className="font-mono text-[11px] uppercase tracking-widest text-stardust">
                  {t.label}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* ---------------- Orbital graphic ---------------- */}
        <div className="relative mx-auto h-[320px] w-full max-w-md md:h-[460px]">
          <div className="absolute inset-0 animate-float">
            {/* Orbital rings */}
            <div className="absolute inset-[8%] animate-[spin_14s_linear_infinite] rounded-full border border-btc/30" />
            <div className="absolute inset-[20%] animate-[spin_20s_linear_infinite_reverse] rounded-full border border-dashed border-gold/25" />
            <div className="absolute inset-[32%] animate-[spin_11s_linear_infinite] rounded-full border border-ember/40" />

            {/* Core orb */}
            <div className="absolute inset-[34%] rounded-full bg-gradient-to-br from-ember via-btc to-gold opacity-90 blur-[2px]" />
            <div className="absolute inset-[34%] flex items-center justify-center rounded-full">
              <Bitcoin className="h-16 w-16 text-black/70 md:h-24 md:w-24" strokeWidth={1.5} />
            </div>
            <div className="absolute inset-[26%] animate-[sheen_3.5s_ease-in-out_infinite] rounded-full bg-btc/30 blur-[60px]" />

            {/* Orbiting node */}
            <div className="absolute inset-[8%] animate-[spin_14s_linear_infinite]">
              <span className="absolute -top-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rounded-full bg-gold shadow-[0_0_20px_rgb(255_214_0_/_0.8)]" />
            </div>
          </div>

          {/* Floating data cards */}
          <Card
            variant="glass"
            className="absolute -left-2 top-6 animate-[drift_6s_ease-in-out_infinite] px-4 py-3 md:left-0"
          >
            <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
              Net APY
            </p>
            <p className="font-heading text-xl font-bold text-gold">8.42%</p>
          </Card>

          <Card
            variant="glass"
            className="absolute -right-1 bottom-10 animate-[drift_7s_ease-in-out_infinite] px-4 py-3 [animation-delay:1.2s] md:right-0"
          >
            <div className="flex items-center gap-3">
              <span className="rounded-lg border border-ember/50 bg-ember/20 p-2">
                <TrendingUp className="h-4 w-4 text-btc" />
              </span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                  TVL
                </p>
                <p className="font-heading text-lg font-bold text-white">₿ 24,118</p>
              </div>
            </div>
          </Card>

          <Card
            variant="glass"
            className="absolute bottom-0 left-4 animate-[drift_8s_ease-in-out_infinite] px-4 py-2 [animation-delay:0.6s]"
          >
            <p className="font-mono text-[11px] tracking-widest text-btc">
              0xA1…9F4 <span className="text-stardust">settled</span>
            </p>
          </Card>
        </div>
      </Container>
    </section>
  );
}
