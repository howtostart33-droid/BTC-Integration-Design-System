import { useState } from "react";
import { ArrowUpRight, RefreshCw, TrendingUp } from "lucide-react";
import { Badge, LiveDot } from "../ui/Badge";
import { ButtonLink } from "../ui/Button";
import { Card } from "../ui/Card";
import { Container, GlowBlob, SectionHeading } from "../ui/Layout";
import { useDEXGateway } from "../../context/DEXGatewayContext";
import { cn } from "../../utils/cn";

type Vault = {
  name: string;
  code: string;
  apy: string;
  tvlBtc: number;
  tvl: string;
  spreadBps: number;
  risk: "Low" | "Medium" | "High";
  band: "conservative" | "balanced" | "degen";
};

const vaults: Vault[] = [
  { name: "Sovereign Lend", code: "SVL-01", apy: "4.18%", tvlBtc: 6420, tvl: "₿ 6,420", spreadBps: -2, risk: "Low", band: "conservative" },
  { name: "Treasury Notes", code: "TSY-04", apy: "5.02%", tvlBtc: 3980, tvl: "₿ 3,980", spreadBps: 0, risk: "Low", band: "conservative" },
  { name: "Basis Neutral", code: "BSN-11", apy: "8.42%", tvlBtc: 7215, tvl: "₿ 7,215", spreadBps: 3, risk: "Medium", band: "balanced" },
  { name: "Liquidity Router", code: "LQR-07", apy: "9.86%", tvlBtc: 2884, tvl: "₿ 2,884", spreadBps: 5, risk: "Medium", band: "balanced" },
  { name: "Volatility Harvest", code: "VLH-02", apy: "14.30%", tvlBtc: 1509, tvl: "₿ 1,509", spreadBps: 9, risk: "High", band: "degen" },
  { name: "Leveraged Stack", code: "LVS-09", apy: "21.74%", tvlBtc: 1110, tvl: "₿ 1,110", spreadBps: 14, risk: "High", band: "degen" },
];

const filters = [
  { key: "all", label: "All vaults" },
  { key: "conservative", label: "Conservative" },
  { key: "balanced", label: "Balanced" },
  { key: "degen", label: "High yield" },
] as const;

const riskTone: Record<Vault["risk"], string> = {
  Low: "text-gold border-gold/40 bg-gold/10",
  Medium: "text-btc border-btc/40 bg-btc/10",
  High: "text-ember border-ember/50 bg-ember/10",
};

function formatUsdPrice(value: number) {
  return `$${value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function formatUsdCompact(value: number) {
  if (value >= 1_000_000_000) {
    return `$${(value / 1_000_000_000).toFixed(2)}B`;
  }
  return `$${(value / 1_000_000).toFixed(2)}M`;
}

export function OptionAVaultsTable() {
  const [active, setActive] = useState<(typeof filters)[number]["key"]>("all");
  const { liveMarket, refreshLiveMarket, openGateway } = useDEXGateway();
  const rows = vaults.filter((v) => active === "all" || v.band === active);

  const totalFilteredBtc = rows.reduce((acc, v) => acc + v.tvlBtc, 0);
  const totalFilteredUsd = totalFilteredBtc * liveMarket.btcSpotPrice;

  return (
    <div className="relative">
      <GlowBlob className="-left-32 top-10 h-[400px] w-[400px]" color="gold" />
      <Container className="relative">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeading
            eyebrow="Live trading & vaults"
            title="Trading, priced by"
            accent="the live market price."
            align="left"
            description="Rates update every confirmation. No lockups, no rehypothecation, no hidden counterparties."
          />
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2.5 rounded-full border border-btc/40 bg-btc/10 px-4 py-1.5 font-mono text-xs text-white shadow-[0_0_20px_-6px_rgb(247_147_26_/_0.6)]">
              <TrendingUp className="h-3.5 w-3.5 text-btc" />
              <span className="text-stardust">BTC/USD:</span>
              <span
                className={cn(
                  "font-semibold transition-colors duration-300",
                  liveMarket.direction === "up" ? "text-gold" : "text-ember"
                )}
              >
                {formatUsdPrice(liveMarket.btcSpotPrice)}
              </span>
              <span
                className={cn(
                  "text-[10px]",
                  liveMarket.change24h >= 0 ? "text-gold" : "text-ember"
                )}
              >
                ({liveMarket.change24h >= 0 ? "+" : ""}
                {liveMarket.change24h.toFixed(2)}%)
              </span>
            </div>

            <Badge variant="default" className="w-fit pl-3">
              <LiveDot />
              Updated {liveMarket.secondsSinceUpdate}s ago
              <button
                type="button"
                onClick={refreshLiveMarket}
                title="Refresh live market price"
                className="ml-1 rounded p-0.5 text-stardust hover:text-white focus-visible:outline-none"
              >
                <RefreshCw className="h-3 w-3" />
              </button>
            </Badge>
          </div>
        </div>

        {/* Filters */}
        <div className="mt-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Vault risk filter">
            {filters.map((f) => (
              <button
                key={f.key}
                role="tab"
                aria-selected={active === f.key}
                onClick={() => setActive(f.key)}
                className={cn(
                  "rounded-full border px-4 py-2 font-mono text-[11px] uppercase tracking-widest transition-all duration-200",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc",
                  active === f.key
                    ? "border-btc bg-btc/10 text-btc shadow-[0_0_20px_-6px_rgb(247_147_26_/_0.8)]"
                    : "border-white/10 text-stardust hover:border-btc/50 hover:text-white",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="font-mono text-[11px] uppercase tracking-widest text-stardust">
            Active TVL:{" "}
            <span className="text-white font-semibold">
              ₿ {totalFilteredBtc.toLocaleString()}
            </span>{" "}
            <span className="text-gold">({formatUsdCompact(totalFilteredUsd)} live)</span>
          </div>
        </div>

        <Card variant="glass" className="mt-6 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[740px] border-collapse text-left">
              <caption className="sr-only">Available Satstack trading yield vaults priced by live market</caption>
              <thead>
                <tr className="border-b border-white/10">
                  {["Vault", "Ticker", "Live Market Price", "Net APY", "TVL (BTC & Live USD)", "Risk", ""].map((h) => (
                    <th
                      key={h}
                      scope="col"
                      className="px-6 py-4 font-mono text-[10px] uppercase tracking-widest text-stardust"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((v) => {
                  const vaultMarkPrice =
                    liveMarket.btcSpotPrice * (1 + v.spreadBps / 10000);
                  const vaultUsdTvl = v.tvlBtc * liveMarket.btcSpotPrice;

                  return (
                    <tr
                      key={v.code}
                      className="group border-b border-white/5 transition-colors duration-200 last:border-0 hover:bg-btc/[0.04]"
                    >
                      <td className="px-6 py-5 font-heading font-semibold text-white">{v.name}</td>
                      <td className="px-6 py-5 font-mono text-xs text-stardust">{v.code}</td>
                      <td className="px-6 py-5">
                        <div className="font-mono text-sm font-medium text-white">
                          {formatUsdPrice(vaultMarkPrice)}
                        </div>
                        <div className="font-mono text-[10px] text-btc">
                          Live Spot {v.spreadBps >= 0 ? `+${v.spreadBps}` : v.spreadBps} bps
                        </div>
                      </td>
                      <td className="px-6 py-5 font-mono text-base font-medium text-gold">{v.apy}</td>
                      <td className="px-6 py-5">
                        <div className="font-mono text-sm text-white">{v.tvl}</div>
                        <div className="font-mono text-[11px] text-stardust">
                          {formatUsdCompact(vaultUsdTvl)} @ live market
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <span
                          className={cn(
                            "rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-widest",
                            riskTone[v.risk],
                          )}
                        >
                          {v.risk}
                        </span>
                      </td>
                      <td className="px-6 py-5 text-right">
                        <button
                          type="button"
                          onClick={openGateway}
                          className="inline-flex items-center gap-1 rounded font-mono text-[11px] uppercase tracking-widest text-stardust transition-colors duration-200 hover:text-btc focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
                        >
                          Trade / Deposit
                          <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="mt-8 flex justify-center">
          <ButtonLink href="#cta" variant="link">
            View full strategy documentation
          </ButtonLink>
        </div>
      </Container>
    </div>
  );
}
