import { useEffect, useState, useRef } from "react";
import { Menu, X, Bitcoin, Wallet, LogOut, ChevronDown, Activity, Sparkles } from "lucide-react";
import { Button } from "../ui/Button";
import { Container } from "../ui/Layout";
import { Badge } from "../ui/Badge";
import { useDEXGateway } from "../../context/DEXGatewayContext";
import { cn } from "../../utils/cn";

const links = [
  { label: "Vaults", href: "#vaults" },
  { label: "Protocol", href: "#features" },
  { label: "Process", href: "#process" },
  { label: "Tiers", href: "#pricing" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const {
    wallet,
    openGateway,
    openTelemetry,
    disconnectWallet,
    telemetry,
  } = useDEXGateway();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-white/10 bg-void/80 backdrop-blur-lg"
          : "border-b border-transparent",
      )}
    >
      <Container className="flex h-18 items-center justify-between py-4">
        {/* Logo */}
        <a
          href="#top"
          className="group flex items-center gap-3 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
        >
          <span className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-ember/50 bg-ember/20 transition-all duration-300 group-hover:shadow-[0_0_20px_rgb(234_88_12_/_0.4)]">
            <Bitcoin className="h-5 w-5 text-btc" />
          </span>
          <span className="font-heading text-lg font-bold tracking-tight text-white">
            sat<span className="text-gradient-btc">stack</span>
          </span>
        </a>

        {/* Primary Nav Links */}
        <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded font-mono text-xs uppercase tracking-widest text-stardust transition-colors duration-200 hover:text-btc focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* Back-Office Telemetry Button + Wallet Connect Gateway */}
        <div className="flex items-center gap-3">
          {/* Telemetry pill button */}
          <button
            type="button"
            onClick={openTelemetry}
            className="hidden sm:inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/5 px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider text-gold hover:border-gold/60 hover:bg-gold/10 hover:shadow-[0_0_20px_rgb(255_214_0_/_0.2)] transition-all"
            title="Inspect backend telemetry: wallet connections and take changes"
          >
            <Activity className="h-3 w-3 animate-pulse text-gold" />
            <span>Telemetry: {telemetry.totalWalletsConnected.toLocaleString()} Wallets</span>
            <span className="rounded bg-gold/20 px-1 text-[9px] text-white">
              {telemetry.totalTakeChanges} Takes
            </span>
          </button>

          {/* Connected state vs Connect button */}
          {wallet ? (
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setDropdownOpen((prev) => !prev)}
                className="inline-flex items-center gap-2.5 rounded-full border border-btc/50 bg-surface/90 px-3.5 py-1.5 font-mono text-xs text-white transition-all hover:border-btc hover:shadow-[0_0_25px_-5px_rgb(247_147_26_/_0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
              >
                <span className="flex h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgb(52_211_153)]" />
                <span className="text-btc font-medium">₿ {wallet.balanceBtc}</span>
                <span className="text-stardust">|</span>
                <span className="text-white font-medium">{wallet.address.slice(0, 5)}...{wallet.address.slice(-4)}</span>
                <ChevronDown className="h-3.5 w-3.5 text-stardust" />
              </button>

              {/* Wallet Dropdown Menu */}
              {dropdownOpen && (
                <div className="absolute right-0 top-full mt-2 w-72 overflow-hidden rounded-2xl border border-white/10 bg-surface/95 p-2 shadow-[0_0_40px_-5px_rgb(247_147_26_/_0.3)] backdrop-blur-xl">
                  <div className="border-b border-white/10 px-3 py-2.5">
                    <p className="font-mono text-[10px] uppercase tracking-wider text-stardust">
                      Connected to {wallet.network}
                    </p>
                    <p className="mt-1 font-mono text-xs font-semibold text-white break-all">
                      {wallet.address}
                    </p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="font-mono text-[11px] text-stardust">Tier Fee Take:</span>
                      <Badge variant="btc" size="sm" className="text-[10px]">
                        {wallet.tier} ({wallet.tier === "Self" ? "0%" : wallet.tier === "Stacker" ? "8%" : "Custom"})
                      </Badge>
                    </div>
                  </div>

                  <div className="py-1">
                    <button
                      type="button"
                      onClick={() => {
                        setDropdownOpen(false);
                        openTelemetry();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-mono text-xs text-stardust hover:bg-white/5 hover:text-white"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-gold" />
                      View Back-Office Stats
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDropdownOpen(false);
                        openGateway();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-mono text-xs text-stardust hover:bg-white/5 hover:text-white"
                    >
                      <Wallet className="h-3.5 w-3.5 text-btc" />
                      Switch DEX / Address
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDropdownOpen(false);
                        disconnectWallet();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 font-mono text-xs text-ember hover:bg-ember/10"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      Disconnect Wallet
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <Button
              onClick={openGateway}
              size="sm"
              className="gap-1.5"
            >
              <Wallet className="h-3.5 w-3.5" />
              Connect
            </Button>
          )}

          {/* Mobile menu toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </Container>

      {/* Mobile nav drawer */}
      {open && (
        <div className="border-t border-white/10 bg-void/95 backdrop-blur-lg lg:hidden">
          <Container className="flex flex-col py-4 gap-2">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 font-mono text-sm uppercase tracking-widest text-stardust transition-colors hover:bg-white/5 hover:text-btc"
              >
                {l.label}
              </a>
            ))}

            <div className="border-t border-white/10 pt-3 mt-2 flex flex-col gap-2">
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  openTelemetry();
                }}
                className="flex items-center justify-between rounded-lg border border-gold/30 bg-gold/10 px-3 py-2.5 font-mono text-xs text-gold"
              >
                <span className="flex items-center gap-2">
                  <Activity className="h-3.5 w-3.5" />
                  Protocol Telemetry &amp; Take Changes
                </span>
                <span className="rounded bg-gold/20 px-1.5 py-0.5 text-[10px]">
                  {telemetry.totalWalletsConnected} Wallets
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  openGateway();
                }}
                className="flex items-center justify-center gap-2 rounded-full border border-btc bg-btc/10 py-3 font-mono text-xs uppercase tracking-wider text-btc"
              >
                <Wallet className="h-4 w-4" />
                {wallet ? `Switch DEX Address (${wallet.address.slice(0, 6)}...)` : "Connect on DEXs / Address"}
              </button>
            </div>
          </Container>
        </div>
      )}
    </header>
  );
}
