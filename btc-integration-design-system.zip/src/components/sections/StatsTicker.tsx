import { useDEXGateway } from "../../context/DEXGatewayContext";

export function StatsTicker() {
  const { telemetry, liveMarket } = useDEXGateway();

  const formattedSpot = `$${liveMarket.btcSpotPrice.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
  const formattedDelta = `${liveMarket.change24h >= 0 ? "+" : ""}${liveMarket.change24h.toFixed(2)}%`;

  const ticks = [
    { pair: "BTC/USD LIVE", value: formattedSpot, delta: formattedDelta, up: liveMarket.change24h >= 0 },
    { pair: "DEX WALLETS", value: `${telemetry.totalWalletsConnected.toLocaleString()} active`, delta: "+18 new", up: true },
    { pair: "TAKE CHANGES", value: `${telemetry.totalTakeChanges.toLocaleString()} shifts`, delta: "8% stacker", up: true },
    { pair: "TVL", value: "₿ 24,118", delta: "+118 BTC", up: true },
    { pair: "AVG APY", value: "8.42%", delta: "+0.31", up: true },
    { pair: "SETTLED 24H", value: "18,904 tx", delta: "+6.2%", up: true },
    { pair: "GAS", value: "12 sat/vB", delta: "-3.4%", up: false },
  ];

  const row = [...ticks, ...ticks];
  return (
    <div className="relative border-y border-white/10 bg-surface py-4">
      <div className="mask-fade-x overflow-hidden">
        <div className="flex w-max animate-[ticker_40s_linear_infinite] items-center gap-10 pr-10">
          {row.map((t, i) => (
            <div key={i} className="flex items-center gap-3 whitespace-nowrap">
              <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                {t.pair}
              </span>
              <span className="font-mono text-sm font-medium text-white">{t.value}</span>
              <span
                className={`font-mono text-xs ${t.up ? "text-gold" : "text-ember"}`}
              >
                {t.delta}
              </span>
              <span aria-hidden className="h-4 w-px bg-white/10" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
