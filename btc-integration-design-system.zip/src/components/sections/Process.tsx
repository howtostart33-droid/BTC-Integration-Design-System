import { Card, CardContent, CardDescription, CardTitle, CornerAccents } from "../ui/Card";
import { Container, GlowBlob, Section, SectionHeading } from "../ui/Layout";

const steps = [
  {
    n: "01",
    title: "Connect a wallet",
    body: "Link any hardware or software wallet. Satstack derives a vault address and never requests your seed.",
    meta: "~15 sec",
  },
  {
    n: "02",
    title: "Select a vault",
    body: "Choose a risk band from conservative lending to delta-neutral basis. Every parameter is public.",
    meta: "6 strategies",
  },
  {
    n: "03",
    title: "Deposit sats",
    body: "Fund over Lightning or on-chain. Your multisig position opens as soon as the block confirms.",
    meta: "1 confirmation",
  },
  {
    n: "04",
    title: "Earn & verify",
    body: "Yield accrues per block. Withdraw anytime and audit every movement against the Merkle proof.",
    meta: "no lockups",
  },
];

export function Process() {
  return (
    <Section id="process" tone="surface">
      <GlowBlob className="-right-24 bottom-0 h-[420px] w-[420px]" color="btc" />
      <Container className="relative">
        <SectionHeading
          eyebrow="How it works"
          title="Four blocks to"
          accent="yield."
          align="left"
        />

        {/* Ledger: vertical gradient chain with node markers */}
        <ol className="relative mt-14 space-y-8 pl-10 md:space-y-10 md:pl-0">
          <span
            aria-hidden
            className="absolute bottom-6 left-[15px] top-2 w-px bg-gradient-to-b from-btc via-btc/40 to-transparent md:left-1/2 md:-translate-x-1/2"
          />
          {steps.map((s, i) => (
            <li
              key={s.n}
              className="relative md:grid md:grid-cols-[1fr_auto_1fr] md:items-center md:gap-10"
            >
              <Card
                variant="glass"
                interactive
                className={`group md:row-start-1 ${
                  i % 2 === 0 ? "md:col-start-1 md:text-right" : "md:col-start-3"
                }`}
              >
                <CornerAccents className="opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <CardContent className="space-y-3 p-7">
                  <div
                    className={`flex items-center gap-3 ${i % 2 === 0 ? "md:justify-end" : ""}`}
                  >
                    <span className="font-mono text-xs tracking-widest text-btc">{s.n}</span>
                    <span className="h-px w-8 bg-btc/40" />
                    <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                      {s.meta}
                    </span>
                  </div>
                  <CardTitle className="text-xl md:text-2xl">{s.title}</CardTitle>
                  <CardDescription>{s.body}</CardDescription>
                </CardContent>
              </Card>

              {/* Node marker */}
              <span className="absolute left-[-25px] top-7 flex h-8 w-8 items-center justify-center rounded-full border border-btc/50 bg-void font-mono text-[11px] text-btc shadow-[0_0_20px_-4px_rgb(247_147_26_/_0.8)] md:static md:col-start-2 md:row-start-1 md:h-10 md:w-10 md:text-xs">
                {s.n}
              </span>
            </li>
          ))}
        </ol>
      </Container>
    </Section>
  );
}
