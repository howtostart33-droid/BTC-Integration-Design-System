import { useMemo, useState } from "react";
import {
  Activity,
  ArrowUpRight,
  TrendingUp,
  Wallet,
  ShieldCheck,
  BarChart3,
  ListFilter,
  RefreshCw,
} from "lucide-react";
import { Badge, LiveDot } from "../ui/Badge";
import { Button, ButtonLink } from "../ui/Button";
import { Card } from "../ui/Card";
import { Container, GlowBlob, Section, SectionHeading } from "../ui/Layout";
import { OptionAVaultsTable } from "./OptionAVaultsTable";
import { useDEXGateway, type LiveMarketData } from "../../context/DEXGatewayContext";
import { cn } from "../../utils/cn";

type FilterKey = "all" | "conservative" | "balanced" | "degen";
type RangeKey = "1H" | "1D" | "1W" | "1M" | "1Y" | "ALL";

type MarketProfile = {
  label: string;
  apy: string;
  tvlBtc: number;
  tvl: string;
  volatilityFactor: number;
  spreadBps: number;
};

const filters: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All vaults" },
  { key: "conservative", label: "Conservative" },
  { key: "balanced", label: "Balanced" },
  { key: "degen", label: "High yield" },
];

const ranges: RangeKey[] = ["1H", "1D", "1W", "1M", "1Y", "ALL"];

const marketProfiles: Record<FilterKey, MarketProfile> = {
  all: {
    label: "All vaults live market index",
    apy: "8.42%",
    tvlBtc: 24118,
    tvl: "₿ 24,118",
    volatilityFactor: 1.0,
    spreadBps: 0,
  },
  conservative: {
    label: "Conservative live market index",
    apy: "4.60%",
    tvlBtc: 10400,
    tvl: "₿ 10,400",
    volatilityFactor: 0.45,
    spreadBps: -2,
  },
  balanced: {
    label: "Balanced live market index",
    apy: "8.42%",
    tvlBtc: 10099,
    tvl: "₿ 10,099",
    volatilityFactor: 1.15,
    spreadBps: 4,
  },
  degen: {
    label: "High yield live market index",
    apy: "18.02%",
    tvlBtc: 2619,
    tvl: "₿ 2,619",
    volatilityFactor: 2.1,
    spreadBps: 11,
  },
};

function formatPrice(value: number) {
  return `$${value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function formatAxis(value: number) {
  return `$${(value / 1000).toFixed(1)}k`;
}

function formatUsdCompact(value: number) {
  if (value >= 1_000_000_000) {
    return `$${(value / 1_000_000_000).toFixed(2)}B`;
  }
  return `$${(value / 1_000_000).toFixed(2)}M`;
}

function buildLiveValues(
  liveMarket: LiveMarketData,
  profile: MarketProfile,
  range: RangeKey
): number[] {
  const spotWithSpread = liveMarket.btcSpotPrice * (1 + profile.spreadBps / 10000);
  const baseSeries = liveMarket.liveTickHistory;
  const lastBase = baseSeries[baseSeries.length - 1] || spotWithSpread;

  // Anchor series to live spot price and profile volatility
  const anchored = baseSeries.map((val, idx) => {
    if (idx === baseSeries.length - 1) {
      return Number(spotWithSpread.toFixed(2));
    }
    const diffFromEnd = val - lastBase;
    const rangeMultiplier =
      range === "1H"
        ? 0.35
        : range === "1D"
        ? 0.85
        : range === "1W"
        ? 1.4
        : range === "1M"
        ? 2.2
        : range === "1Y"
        ? 4.0
        : 5.2;
    return Number(
      (spotWithSpread + diffFromEnd * profile.volatilityFactor * rangeMultiplier).toFixed(2)
    );
  });

  if (range === "1H") return anchored.slice(-12);
  if (range === "1D") return anchored.slice(-20);
  if (range === "1W") return anchored.slice(-28);
  return anchored;
}

type MarketChartProps = {
  profile: MarketProfile;
  range: RangeKey;
  liveMarket: LiveMarketData;
  onRangeChange: (range: RangeKey) => void;
  onConnectDEX: () => void;
};

function MarketChart({
  profile,
  range,
  liveMarket,
  onRangeChange,
  onConnectDEX,
}: MarketChartProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const values = useMemo(
    () => buildLiveValues(liveMarket, profile, range),
    [liveMarket, profile, range]
  );

  const chart = useMemo(() => {
    const width = 900;
    const height = 350;
    const left = 14;
    const right = 72;
    const top = 22;
    const bottom = 238;
    const min = Math.min(...values) - 450;
    const max = Math.max(...values) + 450;
    const x = (index: number) =>
      left + (index / Math.max(values.length - 1, 1)) * (width - left - right);
    const y = (value: number) =>
      top + ((max - value) / Math.max(max - min, 1)) * (bottom - top);
    const points = values.map((value, index) => ({ x: x(index), y: y(value), value }));
    const line = points
      .map((point, index) => `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`)
      .join(" ");
    const area = `${line} L ${points[points.length - 1].x} ${bottom} L ${points[0].x} ${bottom} Z`;
    const ticks = Array.from({ length: 5 }, (_, index) => {
      const value = max - ((max - min) / 4) * index;
      return { value, y: y(value) };
    });
    return { width, height, left, right, top, bottom, min, max, points, line, area, ticks };
  }, [values]);

  const selectedPoint =
    hovered === null ? chart.points[chart.points.length - 1] : chart.points[hovered];
  const change = ((values[values.length - 1] - values[0]) / values[0]) * 100;
  const liveUsdTvl = profile.tvlBtc * liveMarket.btcSpotPrice;

  return (
    <div className="relative border-t border-white/10">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 px-5 py-4 md:px-7">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-ember/50 bg-ember/20">
            <TrendingUp className="h-4 w-4 text-btc" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <p className="font-heading text-sm font-semibold text-white">
                BTC / USD · Live Market Price
              </p>
              <span className="rounded bg-gold/15 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-gold">
                {liveMarket.source}
              </span>
            </div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
              {profile.label}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest text-stardust">
          <Button
            size="sm"
            variant="outline"
            onClick={onConnectDEX}
            className="h-8 px-3 text-[10px] border-btc/40 text-btc hover:bg-btc/10"
          >
            <Wallet className="h-3 w-3 mr-1" />
            Connect DEX Address
          </Button>
          <span className="text-gold hidden sm:inline">Block 887,413</span>
        </div>
      </div>

      <div className="relative px-2 pt-4 sm:px-5 md:px-7">
        <div className="mb-2 flex flex-wrap items-start justify-between gap-4 px-2">
          <div>
            <div className="flex items-baseline gap-3">
              <p
                className={cn(
                  "font-mono text-2xl font-medium tracking-tight md:text-3xl transition-colors duration-300",
                  hovered === null && liveMarket.direction === "up"
                    ? "text-white"
                    : "text-white"
                )}
              >
                {formatPrice(selectedPoint.value)}
              </p>
              <span
                className={cn(
                  "rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase",
                  liveMarket.direction === "up"
                    ? "border-gold/40 bg-gold/10 text-gold"
                    : "border-ember/40 bg-ember/10 text-ember"
                )}
              >
                {liveMarket.direction === "up" ? "▲ Live Tick" : "▼ Live Tick"}
              </span>
            </div>
            <p className="mt-1 font-mono text-xs text-gold">
              {change >= 0 ? "+" : ""}
              {change.toFixed(2)}% <span className="text-stardust">({range})</span>
              <span className="ml-3 text-stardust">
                24h High:{" "}
                <strong className="text-white">{formatPrice(liveMarket.high24h)}</strong>
              </span>
              <span className="ml-3 hidden sm:inline text-stardust">
                24h Low:{" "}
                <strong className="text-white">{formatPrice(liveMarket.low24h)}</strong>
              </span>
            </p>
          </div>
          <div className="text-right font-mono text-[10px] uppercase tracking-widest text-stardust">
            <p>Live Market Feed</p>
            <p className="mt-1 text-white">Updated {liveMarket.secondsSinceUpdate}s ago</p>
          </div>
        </div>

        <div className="relative aspect-[2/1] min-h-[230px] w-full overflow-hidden sm:aspect-[2.45/1]">
          <svg
            viewBox={`0 0 ${chart.width} ${chart.height}`}
            className="h-full w-full"
            role="img"
            aria-label={`${profile.label} BTC live market price chart for ${range}`}
            onMouseLeave={() => setHovered(null)}
          >
            <defs>
              <linearGradient id="market-area-fill" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="#F7931A" stopOpacity="0.32" />
                <stop offset="100%" stopColor="#F7931A" stopOpacity="0" />
              </linearGradient>
              <linearGradient id="market-line" x1="0" x2="1" y1="0" y2="0">
                <stop offset="0%" stopColor="#EA580C" />
                <stop offset="100%" stopColor="#FFD600" />
              </linearGradient>
            </defs>

            {chart.ticks.map((tick) => (
              <g key={tick.value}>
                <line
                  x1={chart.left}
                  x2={chart.width - chart.right}
                  y1={tick.y}
                  y2={tick.y}
                  stroke="#1E293B"
                  strokeOpacity="0.75"
                  strokeDasharray="3 7"
                />
                <text
                  x={chart.width - chart.right + 12}
                  y={tick.y + 4}
                  fill="#94A3B8"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="11"
                >
                  {formatAxis(tick.value)}
                </text>
              </g>
            ))}

            {chart.points.map((point, index) => {
              const volumeHeight = 16 + Math.round((index * 19 + point.value) % 42);
              return (
                <rect
                  key={`volume-${index}`}
                  x={point.x - 4}
                  y={chart.height - volumeHeight - 20}
                  width="7"
                  height={volumeHeight}
                  rx="1"
                  fill={index % 3 === 0 ? "#F7931A" : "#94A3B8"}
                  fillOpacity={index % 3 === 0 ? "0.22" : "0.11"}
                />
              );
            })}

            <path d={chart.area} fill="url(#market-area-fill)" />
            <path
              d={chart.line}
              fill="none"
              stroke="url(#market-line)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="3"
            />

            {hovered !== null && (
              <line
                x1={chart.points[hovered].x}
                x2={chart.points[hovered].x}
                y1={chart.top}
                y2={chart.bottom}
                stroke="#F7931A"
                strokeOpacity="0.45"
                strokeDasharray="4 5"
              />
            )}

            {chart.points.map((point, index) => (
              <circle
                key={`point-${index}`}
                cx={point.x}
                cy={point.y}
                r={hovered === index || index === chart.points.length - 1 ? 6 : 3}
                fill={
                  hovered === index || index === chart.points.length - 1
                    ? "#FFD600"
                    : "#F7931A"
                }
                stroke="#030304"
                strokeWidth="2"
                tabIndex={0}
                aria-label={`${formatPrice(point.value)} at point ${index + 1}`}
                onMouseEnter={() => setHovered(index)}
                onFocus={() => setHovered(index)}
              />
            ))}

            <text
              x={chart.left}
              y={chart.height - 4}
              fill="#94A3B8"
              fontFamily="JetBrains Mono, monospace"
              fontSize="10"
            >
              {range === "1H" ? "60 min ago" : range === "1D" ? "24 hrs ago" : "Start"}
            </text>
            <text
              x={chart.width - chart.right}
              y={chart.height - 4}
              textAnchor="end"
              fill="#FFD600"
              fontFamily="JetBrains Mono, monospace"
              fontSize="10"
            >
              Live Market Now
            </text>
          </svg>

          <div className="pointer-events-none absolute right-16 top-3 hidden rounded-lg border border-btc/30 bg-void/90 px-3 py-2 backdrop-blur-sm sm:block">
            <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
              {hovered === null ? "Live Market Price" : "Selected Point Price"}
            </p>
            <p className="mt-1 font-mono text-sm text-gold">
              {formatPrice(selectedPoint.value)}
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4 border-t border-white/10 px-5 py-4 md:flex-row md:items-center md:justify-between md:px-7">
        <div className="flex items-center gap-2">
          {ranges.map((option) => (
            <button
              key={option}
              type="button"
              aria-label={`Show ${option} chart range`}
              aria-pressed={range === option}
              onClick={() => {
                setHovered(null);
                onRangeChange(option);
              }}
              className={cn(
                "rounded px-2.5 py-1.5 font-mono text-[10px] uppercase tracking-widest transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc",
                range === option
                  ? "bg-btc/15 text-btc"
                  : "text-stardust hover:bg-white/5 hover:text-white"
              )}
            >
              {option}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center justify-between gap-6 font-mono text-[10px] uppercase tracking-widest text-stardust md:justify-end">
          <span>
            Vault APY <strong className="ml-2 font-medium text-gold">{profile.apy}</strong>
          </span>
          <span>
            TVL{" "}
            <strong className="ml-2 font-medium text-white">{profile.tvl}</strong>{" "}
            <span className="text-gold">({formatUsdCompact(liveUsdTvl)} live)</span>
          </span>
        </div>
      </div>
    </div>
  );
}

export function Vaults() {
  const {
    openGateway,
    activeView,
    setActiveView,
    liveMarket,
    refreshLiveMarket,
  } = useDEXGateway();
  const [active, setActive] = useState<FilterKey>("all");
  const [range, setRange] = useState<RangeKey>("1D");
  const profile = marketProfiles[active];

  return (
    <Section id="vaults" tone="void">
      {/* View Switcher Bar to compare Option A and Option B, both priced by the live market price */}
      <Container className="mb-8">
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/10 bg-surface/80 p-3 backdrop-blur-md">
          <div className="flex items-center gap-2 font-mono text-xs text-stardust">
            <span className="text-white font-semibold">View Mode:</span>
            <span className="hidden sm:inline">
              Both Option A &amp; Option B are priced by the live BTC/USD market price (
              <strong className="text-gold">{formatPrice(liveMarket.btcSpotPrice)}</strong>)
            </span>
          </div>

          <div className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-black/60 p-1">
            <button
              type="button"
              onClick={() => setActiveView("optionA")}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3 py-1.5 font-mono text-xs uppercase tracking-wider transition-all",
                activeView === "optionA"
                  ? "border border-btc/40 bg-btc/20 text-btc font-semibold shadow-[0_0_15px_-3px_rgb(247_147_26_/_0.8)]"
                  : "text-stardust hover:text-white"
              )}
            >
              <ListFilter className="h-3.5 w-3.5" />
              Option A: Classic Vaults
            </button>
            <button
              type="button"
              onClick={() => setActiveView("optionB")}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3 py-1.5 font-mono text-xs uppercase tracking-wider transition-all",
                activeView === "optionB"
                  ? "border border-gold/40 bg-gold/20 text-gold font-semibold shadow-[0_0_15px_-3px_rgb(255_214_0_/_0.8)]"
                  : "text-stardust hover:text-white"
              )}
            >
              <BarChart3 className="h-3.5 w-3.5" />
              Option B: DEX Trading Chart
            </button>
          </div>
        </div>
      </Container>

      {activeView === "optionA" ? (
        /* OPTION A: TRADING VAULTS TABLE PRICED BY THE LIVE MARKET PRICE */
        <OptionAVaultsTable />
      ) : (
        /* OPTION B: COINMARKETCAP-STYLE DEX TRADING TERMINAL PRICED BY THE LIVE MARKET PRICE */
        <div className="relative">
          <GlowBlob className="-left-32 top-10 h-[400px] w-[400px]" color="gold" />
          <Container className="relative">
            <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
              <SectionHeading
                eyebrow="Live trading"
                title="Trading, priced by"
                accent="the live market price."
                align="left"
                description="Rates update every confirmation. No lockups, no rehypothecation, no hidden counterparties."
              />
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2.5 rounded-full border border-btc/40 bg-btc/10 px-4 py-1.5 font-mono text-xs text-white shadow-[0_0_20px_-6px_rgb(247_147_26_/_0.6)]">
                  <TrendingUp className="h-3.5 w-3.5 text-btc" />
                  <span className="text-stardust">BTC/USD:</span>
                  <span
                    className={cn(
                      "font-semibold transition-colors duration-300",
                      liveMarket.direction === "up" ? "text-gold" : "text-ember"
                    )}
                  >
                    {formatPrice(liveMarket.btcSpotPrice)}
                  </span>
                  <span
                    className={cn(
                      "text-[10px]",
                      liveMarket.change24h >= 0 ? "text-gold" : "text-ember"
                    )}
                  >
                    ({liveMarket.change24h >= 0 ? "+" : ""}
                    {liveMarket.change24h.toFixed(2)}%)
                  </span>
                </div>

                <Badge variant="default" className="w-fit pl-3">
                  <LiveDot />
                  Updated {liveMarket.secondsSinceUpdate}s ago
                  <button
                    type="button"
                    onClick={refreshLiveMarket}
                    title="Refresh live market price"
                    className="ml-1 rounded p-0.5 text-stardust hover:text-white focus-visible:outline-none"
                  >
                    <RefreshCw className="h-3 w-3" />
                  </button>
                </Badge>
              </div>
            </div>

            {/* Filters */}
            <div
              className="mt-10 flex flex-wrap gap-2"
              role="tablist"
              aria-label="Vault risk filter"
            >
              {filters.map((f) => (
                <button
                  key={f.key}
                  role="tab"
                  aria-selected={active === f.key}
                  onClick={() => setActive(f.key)}
                  className={cn(
                    "rounded-full border px-4 py-2 font-mono text-[11px] uppercase tracking-widest transition-all duration-200",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc",
                    active === f.key
                      ? "border-btc bg-btc/10 text-btc shadow-[0_0_20px_-6px_rgb(247_147_26_/_0.8)]"
                      : "border-white/10 text-stardust hover:border-btc/50 hover:text-white"
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <Card
              variant="glass"
              className="mt-6 overflow-hidden shadow-[0_0_50px_-10px_rgb(247_147_26_/_0.12)]"
            >
              <div className="flex flex-col gap-4 border-b border-white/10 px-5 py-4 md:flex-row md:items-center md:justify-between md:px-7">
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-stardust">
                  <Activity className="h-4 w-4 text-btc" />
                  <span>Market overview</span>
                  <span className="text-white/20">/</span>
                  <span className="text-white">BTC Live Spot Index</span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest text-stardust">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="h-3.5 w-3.5 text-btc" />
                    DEX Gateway Router
                  </span>
                  <span className="h-1.5 w-1.5 rounded-full bg-gold shadow-[0_0_10px_rgb(255_214_0_/_0.8)]" />
                  Live market price feed
                </div>
              </div>
              <MarketChart
                profile={profile}
                range={range}
                liveMarket={liveMarket}
                onRangeChange={setRange}
                onConnectDEX={openGateway}
              />
            </Card>

            <div className="mt-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
              <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-stardust">
                <span className="h-2 w-2 rounded-full bg-gold shadow-[0_0_12px_rgb(255_214_0_/_0.65)]" />
                Trading priced by the live market price ({formatPrice(liveMarket.btcSpotPrice)}) · Non-custodial DEX liquidity
              </p>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={openGateway}
                  className="inline-flex items-center gap-1 font-mono text-xs uppercase tracking-wider text-btc hover:underline"
                >
                  Connect with DEX Address <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
                <ButtonLink href="#cta" variant="link">
                  Open a vault <ArrowUpRight className="h-3.5 w-3.5" />
                </ButtonLink>
              </div>
            </div>
          </Container>
        </div>
      )}
    </Section>
  );
}
