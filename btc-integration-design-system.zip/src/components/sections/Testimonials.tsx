import { Quote } from "lucide-react";
import { Card, CardContent } from "../ui/Card";
import { Container, GlowBlob, Section, SectionHeading } from "../ui/Layout";

const quotes = [
  {
    body: "We moved 900 BTC of treasury into Satstack after reading the multisig spec. It's the first yield product our risk committee didn't try to kill.",
    name: "Dana Reyes",
    role: "CFO, Helix Mining",
    initials: "DR",
  },
  {
    body: "Per-block accounting and an exportable Merkle proof. I audited a full quarter of positions in an afternoon.",
    name: "Tomas Lund",
    role: "Independent auditor",
    initials: "TL",
  },
  {
    body: "The de-risking engine unwound my basis position at 3am while I slept. Woke up solvent. That's the whole pitch.",
    name: "Priya Anand",
    role: "Prop trader",
    initials: "PA",
  },
];

export function Testimonials() {
  return (
    <Section tone="void">
      <GlowBlob className="left-1/3 top-1/4 h-[380px] w-[380px]" color="ember" />
      <Container className="relative">
        <SectionHeading
          eyebrow="Signal"
          title="Trusted by people who"
          accent="verify."
        />
        <div className="mt-14 grid gap-8 md:grid-cols-3">
          {quotes.map((q) => (
            <Card key={q.name} variant="glass" interactive className="group flex h-full flex-col">
              <CardContent className="flex flex-1 flex-col gap-6 p-8">
                <Quote className="h-7 w-7 text-btc opacity-40 transition-opacity duration-300 group-hover:opacity-100" />
                <p className="flex-1 text-base leading-relaxed text-white/90">“{q.body}”</p>
                <div className="flex items-center gap-4 border-t border-white/10 pt-5">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-ember to-btc font-mono text-xs font-medium text-white">
                    {q.initials}
                  </span>
                  <div>
                    <p className="font-heading text-sm font-semibold text-white">{q.name}</p>
                    <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                      {q.role}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </Container>
    </Section>
  );
}
