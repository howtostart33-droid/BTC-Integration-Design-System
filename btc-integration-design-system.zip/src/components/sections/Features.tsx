import { Boxes, Globe2, KeyRound, Layers, LineChart, Lock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/Card";
import { Container, GlowBlob, Section, SectionHeading } from "../ui/Layout";

const features = [
  {
    icon: KeyRound,
    title: "Keys stay yours",
    body: "Vault deposits are secured by 2-of-3 multisig with a self-held recovery key. We can never move your sats.",
    tag: "self-custody",
  },
  {
    icon: Layers,
    title: "Composable strategies",
    body: "Stack lending, basis trades, and liquidity routes inside a single position with one signature.",
    tag: "composability",
  },
  {
    icon: LineChart,
    title: "Real-time risk engine",
    body: "Health factors recomputed every block. Automated de-risking fires before liquidation thresholds.",
    tag: "risk",
  },
  {
    icon: Lock,
    title: "Formally verified",
    body: "Core contracts audited by four independent firms with a permanent $3M bug bounty on-chain.",
    tag: "security",
  },
  {
    icon: Globe2,
    title: "Global settlement",
    body: "Lightning in, on-chain out. Settle to any address in under two blocks, 24/7, no intermediaries.",
    tag: "liquidity",
  },
  {
    icon: Boxes,
    title: "Proof of reserve",
    body: "Every satoshi is attested through Merkle proofs you can verify yourself from the public explorer.",
    tag: "transparency",
  },
];

export function Features() {
  return (
    <Section id="features" tone="void">
      <GlowBlob className="left-1/2 top-0 h-[360px] w-[520px] -translate-x-1/2" color="ember" />
      <Container className="relative">
        <SectionHeading
          eyebrow="Protocol"
          title="Engineered for"
          accent="digital gold."
          description="Six primitives that turn idle bitcoin into a productive, verifiable, fully collateralized position."
        />

        <div className="mt-14 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Card key={f.title} interactive className="group overflow-hidden">
              {/* Watermark icon reveals on hover */}
              <f.icon
                aria-hidden
                className="pointer-events-none absolute -right-6 -top-6 h-32 w-32 rotate-12 text-btc opacity-[0.06] transition-all duration-500 group-hover:rotate-6 group-hover:opacity-20"
                strokeWidth={1}
              />
              <CardHeader className="flex flex-col gap-5">
                <span className="inline-flex w-fit rounded-lg border border-ember/50 bg-ember/20 p-3 transition-all duration-300 group-hover:shadow-[0_0_20px_rgb(234_88_12_/_0.4)]">
                  <f.icon className="h-5 w-5 text-btc" />
                </span>
                <CardTitle>{f.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                <CardDescription>{f.body}</CardDescription>
                <p className="font-mono text-[10px] uppercase tracking-widest text-stardust/60 transition-colors duration-300 group-hover:text-btc">
                  // {f.tag}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Container>
    </Section>
  );
}
