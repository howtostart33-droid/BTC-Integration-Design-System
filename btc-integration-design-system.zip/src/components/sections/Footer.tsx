import { Bitcoin, Code2, MessageCircle, Send, Activity, Wallet } from "lucide-react";
import { Container } from "../ui/Layout";
import { useDEXGateway } from "../../context/DEXGatewayContext";

const groups = [
  { title: "Protocol", links: ["Vaults", "Risk model", "Audits", "Proof of reserve"] },
  { title: "Developers", links: ["Documentation", "SDK", "API status", "Bug bounty"] },
  { title: "Company", links: ["About", "Careers", "Press kit", "Contact"] },
];

export function Footer() {
  const { openGateway, openTelemetry, telemetry } = useDEXGateway();

  return (
    <footer className="relative border-t border-white/10 bg-surface">
      <div aria-hidden className="absolute inset-0 bg-grid-fine opacity-40" />
      <Container className="relative py-16">
        <div className="grid gap-12 md:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div className="space-y-5">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-ember/50 bg-ember/20">
                <Bitcoin className="h-5 w-5 text-btc" />
              </span>
              <span className="font-heading text-lg font-bold text-white">
                sat<span className="text-gradient-btc">stack</span>
              </span>
            </div>
            <p className="max-w-xs text-sm leading-relaxed text-stardust">
              A non-custodial yield layer for bitcoin. Built by engineers who verify, not trust.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={openTelemetry}
                className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-gold hover:bg-gold/20 transition-colors"
              >
                <Activity className="h-3 w-3" />
                {telemetry.totalWalletsConnected.toLocaleString()} Wallets · {telemetry.totalTakeChanges} Takes
              </button>
              <button
                type="button"
                onClick={openGateway}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest text-stardust hover:text-btc hover:border-btc/40 transition-colors"
              >
                <Wallet className="h-3 w-3 text-btc" />
                DEX Gateway
              </button>
            </div>
          </div>

          {groups.map((g) => (
            <nav key={g.title} aria-label={g.title} className="space-y-4">
              <h3 className="font-mono text-[10px] uppercase tracking-widest text-btc">
                {g.title}
              </h3>
              <ul className="space-y-3">
                {g.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#top"
                      className="rounded text-sm text-stardust transition-colors duration-200 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-6 border-t border-white/10 pt-8 sm:flex-row">
          <p className="font-mono text-[10px] uppercase tracking-widest text-stardust/70">
            © 2026 Satstack Labs · Bitcoin DeFi Protocol · Telemetry Verified Block 887,413
          </p>
          <div className="flex items-center gap-3">
            {[
              { Icon: Send, label: "Telegram" },
              { Icon: MessageCircle, label: "Discord" },
              { Icon: Code2, label: "GitHub" },
            ].map(({ Icon, label }) => (
              <a
                key={label}
                href="#top"
                aria-label={label}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-stardust transition-all duration-300 hover:border-btc/50 hover:text-btc hover:shadow-[0_0_20px_-6px_rgb(247_147_26_/_0.8)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </Container>
    </footer>
  );
}
