import { useState, type FormEvent } from "react";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Badge, LiveDot } from "../ui/Badge";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Container, GlowBlob, Section } from "../ui/Layout";

export function CallToAction() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email) return;
    setSent(true);
  }

  return (
    <Section id="cta" tone="void" className="py-24 md:py-32">
      <div aria-hidden className="absolute inset-0 bg-grid-pattern opacity-70" />
      <GlowBlob className="left-1/2 top-1/2 h-[520px] w-[720px] -translate-x-1/2 -translate-y-1/2" color="btc" />

      <Container className="relative flex flex-col items-center gap-8 text-center">
        <Badge variant="gold" className="pl-3">
          <LiveDot />
          Whitelist open · 1,204 spots left
        </Badge>

        <h2 className="max-w-3xl font-heading text-3xl font-bold leading-tight tracking-tight text-white sm:text-5xl md:text-6xl">
          Your keys. Your coins.
          <br />
          <span className="text-gradient-btc">Your yield.</span>
        </h2>

        <p className="max-w-xl text-base leading-relaxed text-stardust md:text-lg">
          Join the whitelist for early vault access, protocol notes, and the quarterly
          proof-of-reserve report delivered on-chain.
        </p>

        {sent ? (
          <p className="flex items-center gap-3 rounded-full border border-gold/40 bg-gold/10 px-6 py-3 font-mono text-xs uppercase tracking-widest text-gold">
            <CheckCircle2 className="h-4 w-4" /> Confirmed — check your inbox
          </p>
        ) : (
          <form
            onSubmit={onSubmit}
            className="flex w-full max-w-md flex-col items-stretch gap-4 sm:flex-row"
          >
            <label htmlFor="cta-email" className="sr-only">
              Email address
            </label>
            <Input
              id="cta-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="satoshi@protonmail.com"
              className="flex-1"
            />
            <Button type="submit" className="sm:w-auto">
              Join <ArrowRight className="h-4 w-4" />
            </Button>
          </form>
        )}

        <p className="font-mono text-[10px] uppercase tracking-widest text-stardust/70">
          No spam · Unsubscribe in one click
        </p>
      </Container>
    </Section>
  );
}
