import { Database, ArrowUpRight } from "lucide-react";
import { useDEXGateway } from "../../context/DEXGatewayContext";

export function FloatingTelemetryTrigger() {
  const { openTelemetry, telemetry } = useDEXGateway();

  return (
    <aside aria-label="Live protocol telemetry dock" className="fixed bottom-5 right-5 z-40">
      <button
        type="button"
        onClick={openTelemetry}
        className="group flex items-center gap-2.5 rounded-full border border-gold/40 bg-surface/90 px-4 py-2.5 font-mono text-xs text-white shadow-[0_0_35px_-5px_rgb(255_214_0_/_0.3)] backdrop-blur-xl transition-all duration-300 hover:scale-105 hover:border-gold hover:shadow-[0_0_45px_rgb(255_214_0_/_0.5)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold"
      >
        <span className="relative flex h-2.5 w-2.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold opacity-75" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-gold" />
        </span>
        <Database className="h-3.5 w-3.5 text-btc" />
        <span className="hidden sm:inline font-semibold text-white">Back-Office:</span>
        <span className="text-gold font-bold">{telemetry.totalWalletsConnected.toLocaleString()}</span>
        <span className="hidden md:inline text-stardust">Wallets</span>
        <span className="text-white/20">|</span>
        <span className="text-btc font-bold">{telemetry.totalTakeChanges.toLocaleString()}</span>
        <span className="hidden md:inline text-stardust">Take Shifts</span>
        <span className="rounded-full bg-gold/15 p-1 text-gold transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
          <ArrowUpRight className="h-3 w-3" />
        </span>
      </button>
    </aside>
  );
}
