import { useState } from "react";
import {
  X,
  Activity,
  Layers,
  ArrowUpRight,
  TrendingUp,
  Cpu,
  PlusCircle,
  Database,
  CheckCircle,
} from "lucide-react";
import { useDEXGateway, type PricingTier } from "../../context/DEXGatewayContext";
import { Badge, LiveDot } from "../ui/Badge";
import { Button } from "../ui/Button";
import { Card } from "../ui/Card";
import { cn } from "../../utils/cn";

export function ProtocolTelemetryModal() {
  const {
    isTelemetryOpen,
    closeTelemetry,
    telemetry,
    connectWithProvider,
    changePricingTier,
    wallet,
  } = useDEXGateway();

  const [activeTab, setActiveTab] = useState<"take_changes" | "wallet_connects" | "breakdown">(
    "take_changes"
  );
  const [simulationNote, setSimulationNote] = useState<string | null>(null);

  if (!isTelemetryOpen) return null;

  const totalWallets = telemetry.totalWalletsConnected;
  const selfCount = telemetry.tierDistribution.Self;
  const stackerCount = telemetry.tierDistribution.Stacker;
  const treasuryCount = telemetry.tierDistribution.Treasury;
  const sumTiers = selfCount + stackerCount + treasuryCount;

  const selfPct = ((selfCount / sumTiers) * 100).toFixed(1);
  const stackerPct = ((stackerCount / sumTiers) * 100).toFixed(1);
  const treasuryPct = ((treasuryCount / sumTiers) * 100).toFixed(1);

  // Simulation helpers to give instant proof of back-office reactivity
  const handleSimulateConnect = () => {
    const providers = ["unisat", "thorchain", "xverse", "uniswap_btc", "leather"] as const;
    const randomProvider = providers[Math.floor(Math.random() * providers.length)];
    const mockAddr = `bc1q${Math.random().toString(16).substring(2, 6)}...${Math.random()
      .toString(16)
      .substring(2, 6)}`;
    connectWithProvider(randomProvider, mockAddr);
    setSimulationNote(`✓ Simulated wallet connection recorded for ${mockAddr}`);
    setTimeout(() => setSimulationNote(null), 4000);
  };

  const handleSimulateTakeChange = (targetTier: PricingTier) => {
    changePricingTier(targetTier);
    setSimulationNote(`✓ Recorded "Pay only when you earn" take change to: ${targetTier}`);
    setTimeout(() => setSimulationNote(null), 4000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="telemetry-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-void/90 backdrop-blur-md transition-opacity"
        onClick={closeTelemetry}
      />

      {/* Modal Dialog */}
      <div className="relative flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-btc/40 bg-surface shadow-[0_0_80px_-10px_rgb(247_147_26_/_0.4)]">
        {/* Top Protocol Header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-void/60 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-ember/50 bg-ember/20 shadow-[0_0_20px_-4px_rgb(234_88_12_/_0.7)]">
              <Database className="h-5 w-5 text-btc" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="telemetry-title" className="font-heading text-lg font-bold text-white">
                  Protocol Back-Office & Telemetry
                </h3>
                <Badge variant="gold" size="sm" className="hidden sm:inline-flex">
                  <LiveDot /> Live Ledger Feed
                </Badge>
              </div>
              <p className="font-mono text-xs text-stardust">
                Real-time monitor: DEX wallet connects &amp; "Pay only when you earn" performance fee changes
              </p>
            </div>
          </div>
          <button
            onClick={closeTelemetry}
            aria-label="Close telemetry modal"
            className="rounded-lg p-2 text-stardust transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Highlight notification bar */}
        {simulationNote && (
          <div className="flex items-center gap-2 border-b border-gold/30 bg-gold/10 px-6 py-2.5 font-mono text-xs text-gold">
            <CheckCircle className="h-4 w-4 shrink-0" />
            <span>{simulationNote}</span>
          </div>
        )}

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Key Metric Cards */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {/* Card 1: Wallets Connected */}
            <Card variant="glass" className="p-4 border-btc/30">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                  Wallets Connected
                </span>
                <span className="h-2 w-2 rounded-full bg-btc shadow-[0_0_10px_rgb(247_147_26_/_0.8)]" />
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-white">
                {totalWallets.toLocaleString()}
              </p>
              <p className="mt-1 font-mono text-[10px] text-gold">
                +18 connects in last 100 blocks
              </p>
            </Card>

            {/* Card 2: Take Changes */}
            <Card variant="glass" className="p-4 border-gold/30">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                  Fee Take Changes
                </span>
                <TrendingUp className="h-3.5 w-3.5 text-gold" />
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-gold">
                {telemetry.totalTakeChanges.toLocaleString()}
              </p>
              <p className="mt-1 font-mono text-[10px] text-stardust">
                "Pay only when you earn" updates
              </p>
            </Card>

            {/* Card 3: Performance Fee Accrued */}
            <Card variant="glass" className="p-4 border-white/10">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                  Protocol Take (Accrued)
                </span>
                <Cpu className="h-3.5 w-3.5 text-btc" />
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-white">
                ₿ {telemetry.totalFeeTakeBtc.toFixed(2)}
              </p>
              <p className="mt-1 font-mono text-[10px] text-stardust">
                From ₿ {telemetry.totalYieldGeneratedBtc.toFixed(1)} gross yield
              </p>
            </Card>

            {/* Card 4: Stacker 8% Ratio */}
            <Card variant="glass" className="p-4 border-white/10">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                  Stacker Tier (8% Take)
                </span>
                <Badge variant="btc" size="sm" className="text-[9px] px-1.5 py-0">
                  Most Active
                </Badge>
              </div>
              <p className="mt-2 font-heading text-2xl font-bold text-white">
                {stackerCount.toLocaleString()}{" "}
                <span className="text-sm font-normal text-stardust">({stackerPct}%)</span>
              </p>
              <p className="mt-1 font-mono text-[10px] text-btc">
                Primary revenue generator
              </p>
            </Card>
          </div>

          {/* Breakdown Section: "Pay only when you earn" Fee Take Structure */}
          <Card variant="solid" className="p-5 border-white/10 bg-black/40">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
              <div>
                <h4 className="font-heading text-base font-semibold text-white">
                  "Pay Only When You Earn" Option Take Breakdown
                </h4>
                <p className="font-mono text-xs text-stardust">
                  Real-time distribution of users across performance take tiers:
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleSimulateTakeChange("Stacker")}
                  className="text-[10px] px-3 h-8"
                >
                  <PlusCircle className="h-3 w-3 mr-1" />
                  Simulate Take Change (8%)
                </Button>
                <Button
                  size="sm"
                  variant="primary"
                  onClick={handleSimulateConnect}
                  className="text-[10px] px-3 h-8"
                >
                  <PlusCircle className="h-3 w-3 mr-1" />
                  Simulate Connect
                </Button>
              </div>
            </div>

            {/* Visual Multi-Segment Bar */}
            <div className="mt-5 space-y-2">
              <div className="flex h-3 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  style={{ width: `${selfPct}%` }}
                  className="bg-stardust/80 transition-all duration-500"
                  title={`Self (0% fee): ${selfPct}%`}
                />
                <div
                  style={{ width: `${stackerPct}%` }}
                  className="bg-btc shadow-[0_0_15px_rgb(247_147_26_/_0.8)] transition-all duration-500"
                  title={`Stacker (8% fee): ${stackerPct}%`}
                />
                <div
                  style={{ width: `${treasuryPct}%` }}
                  className="bg-gold shadow-[0_0_15px_rgb(255_214_0_/_0.8)] transition-all duration-500"
                  title={`Treasury (Custom): ${treasuryPct}%`}
                />
              </div>

              {/* Legend & Details */}
              <div className="grid gap-3 pt-3 sm:grid-cols-3">
                <div className="rounded-lg border border-white/5 bg-void/60 p-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-xs text-white">
                      <span className="h-2 w-2 rounded-full bg-stardust" />
                      Self (0% Fee Take)
                    </span>
                    <span className="font-mono text-xs text-stardust">{selfPct}%</span>
                  </div>
                  <p className="mt-1 font-heading text-lg font-bold text-white">
                    {selfCount.toLocaleString()} wallets
                  </p>
                  <p className="font-mono text-[10px] text-stardust/70">
                    Zero performance take on principal or yield
                  </p>
                </div>

                <div className="rounded-lg border border-btc/30 bg-btc/5 p-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-xs text-btc font-semibold">
                      <span className="h-2 w-2 rounded-full bg-btc" />
                      Stacker (8% Yield Take)
                    </span>
                    <span className="font-mono text-xs text-gold font-semibold">{stackerPct}%</span>
                  </div>
                  <p className="mt-1 font-heading text-lg font-bold text-btc">
                    {stackerCount.toLocaleString()} wallets
                  </p>
                  <p className="font-mono text-[10px] text-stardust/70">
                    Protocol takes 8% of yield earned, 0% of principal
                  </p>
                </div>

                <div className="rounded-lg border border-gold/30 bg-gold/5 p-3">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 font-mono text-xs text-gold">
                      <span className="h-2 w-2 rounded-full bg-gold" />
                      Treasury (Custom Take)
                    </span>
                    <span className="font-mono text-xs text-gold">{treasuryPct}%</span>
                  </div>
                  <p className="mt-1 font-heading text-lg font-bold text-white">
                    {treasuryCount.toLocaleString()} desks
                  </p>
                  <p className="font-mono text-[10px] text-stardust/70">
                    Institutional multi-sig & negotiated terms
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Ledger Navigation Tabs */}
          <div>
            <div className="flex border-b border-white/10">
              <button
                type="button"
                onClick={() => setActiveTab("take_changes")}
                className={cn(
                  "flex items-center gap-2 border-b-2 pb-3 font-mono text-xs uppercase tracking-wider transition-all",
                  activeTab === "take_changes"
                    ? "border-gold text-gold font-semibold"
                    : "border-transparent text-stardust hover:text-white"
                )}
              >
                <TrendingUp className="h-3.5 w-3.5" />
                Live "Pay Only When You Earn" Take Changes ({telemetry.recentTakeChanges.length})
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("wallet_connects")}
                className={cn(
                  "ml-6 flex items-center gap-2 border-b-2 pb-3 font-mono text-xs uppercase tracking-wider transition-all",
                  activeTab === "wallet_connects"
                    ? "border-btc text-btc font-semibold"
                    : "border-transparent text-stardust hover:text-white"
                )}
              >
                <Activity className="h-3.5 w-3.5" />
                DEX Wallet Connects Stream ({telemetry.recentConnects.length})
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("breakdown")}
                className={cn(
                  "ml-6 hidden sm:flex items-center gap-2 border-b-2 pb-3 font-mono text-xs uppercase tracking-wider transition-all",
                  activeTab === "breakdown"
                    ? "border-white text-white font-semibold"
                    : "border-transparent text-stardust hover:text-white"
                )}
              >
                <Layers className="h-3.5 w-3.5" />
                DEX Provider Share
              </button>
            </div>

            {/* Tab 1: Take Changes Ledger */}
            {activeTab === "take_changes" && (
              <div className="mt-4 overflow-hidden rounded-xl border border-white/10 bg-black/40">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[640px] border-collapse text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-white/10 bg-void/50 text-[10px] uppercase tracking-wider text-stardust">
                        <th className="px-4 py-3">Block / Time</th>
                        <th className="px-4 py-3">Wallet Address</th>
                        <th className="px-4 py-3">Tier Transition</th>
                        <th className="px-4 py-3">Fee Take Shift</th>
                        <th className="px-4 py-3 text-right">Transaction Hash</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {telemetry.recentTakeChanges.map((tc) => (
                        <tr key={tc.id} className="transition-colors hover:bg-white/[0.03]">
                          <td className="px-4 py-3">
                            <span className="text-white">#{tc.blockHeight}</span>
                            <span className="ml-2 text-[10px] text-stardust">({tc.timestamp})</span>
                          </td>
                          <td className="px-4 py-3 font-medium text-btc">
                            {tc.address}
                            {wallet?.address === tc.address && (
                              <Badge variant="gold" size="sm" className="ml-2 text-[9px] px-1.5 py-0">
                                You
                              </Badge>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-stardust">{tc.fromTier}</span>
                            <span className="mx-2 text-gold">→</span>
                            <span className="font-semibold text-white">{tc.toTier}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="rounded bg-btc/10 px-2 py-0.5 text-btc border border-btc/30">
                              {tc.feeFrom} → {tc.feeTo} take
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right text-stardust">
                            <span className="inline-flex items-center gap-1 hover:text-white cursor-pointer">
                              {tc.txHash} <ArrowUpRight className="h-3 w-3" />
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 2: Wallet Connects Stream */}
            {activeTab === "wallet_connects" && (
              <div className="mt-4 overflow-hidden rounded-xl border border-white/10 bg-black/40">
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[640px] border-collapse text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-white/10 bg-void/50 text-[10px] uppercase tracking-wider text-stardust">
                        <th className="px-4 py-3">Block / Time</th>
                        <th className="px-4 py-3">Connected Address</th>
                        <th className="px-4 py-3">DEX / Provider</th>
                        <th className="px-4 py-3">Settlement Network</th>
                        <th className="px-4 py-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {telemetry.recentConnects.map((cnItem) => (
                        <tr key={cnItem.id} className="transition-colors hover:bg-white/[0.03]">
                          <td className="px-4 py-3">
                            <span className="text-white">#{cnItem.blockHeight}</span>
                            <span className="ml-2 text-[10px] text-stardust">({cnItem.timestamp})</span>
                          </td>
                          <td className="px-4 py-3 font-medium text-white">{cnItem.address}</td>
                          <td className="px-4 py-3">
                            <span className="rounded border border-white/10 bg-white/5 px-2 py-0.5 text-btc uppercase tracking-wider text-[10px]">
                              {cnItem.provider}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-stardust">{cnItem.network}</td>
                          <td className="px-4 py-3 text-right">
                            <span className="inline-flex items-center gap-1 text-[11px] text-gold">
                              <span className="h-1.5 w-1.5 rounded-full bg-gold" />
                              Active Session
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 3: Provider breakdown */}
            {activeTab === "breakdown" && (
              <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {Object.entries(telemetry.providerBreakdown).map(([prov, count]) => (
                  <div key={prov} className="rounded-xl border border-white/10 bg-black/40 p-4">
                    <p className="font-mono text-[10px] uppercase tracking-widest text-stardust">
                      {prov.replace("_", " ")}
                    </p>
                    <p className="mt-1 font-heading text-xl font-bold text-white">
                      {count.toLocaleString()}
                    </p>
                    <p className="mt-1 font-mono text-[10px] text-btc">
                      {((count / totalWallets) * 100).toFixed(1)}% market share
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer info */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/10 bg-void/80 px-6 py-4 font-mono text-xs text-stardust">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-gold animate-pulse" />
            <span>Telemetry verified against Bitcoin block 887,413</span>
          </div>
          <button
            onClick={closeTelemetry}
            className="text-white hover:text-btc underline transition-colors"
          >
            Close Back-Office Monitor
          </button>
        </div>
      </div>
    </div>
  );
}
