import { useState } from "react";
import {
  X,
  Wallet,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Zap,
  Globe,
  Layers,
  Sparkles,
} from "lucide-react";
import { useDEXGateway, type DexProvider } from "../../context/DEXGatewayContext";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Badge, LiveDot } from "../ui/Badge";
import { cn } from "../../utils/cn";

interface GatewayOption {
  id: DexProvider;
  name: string;
  tagline: string;
  badge: string;
  type: "DEX Gateway" | "Bitcoin Wallet" | "Cross-Chain DEX";
  iconBg: string;
  popular?: boolean;
}

const GATEWAY_OPTIONS: GatewayOption[] = [
  {
    id: "thorchain",
    name: "THORChain DEX",
    tagline: "Cross-chain native BTC swaps & liquidity pool",
    badge: "Cross-DEX",
    type: "Cross-Chain DEX",
    iconBg: "from-emerald-500/20 to-btc/20 border-emerald-500/40",
    popular: true,
  },
  {
    id: "uniswap_btc",
    name: "Uniswap BTC Router",
    tagline: "wBTC / cbBTC / Babylon routing bridge",
    badge: "v4 Hooks",
    type: "DEX Gateway",
    iconBg: "from-pink-500/20 to-purple-500/20 border-pink-500/40",
    popular: true,
  },
  {
    id: "unisat",
    name: "UniSat Wallet",
    tagline: "Native Bitcoin Ordinals, Runes & PSBT signer",
    badge: "Native BTC",
    type: "Bitcoin Wallet",
    iconBg: "from-btc/30 to-ember/20 border-btc/50",
    popular: true,
  },
  {
    id: "xverse",
    name: "Xverse Wallet",
    tagline: "Taproot & Stacks Bitcoin Web3 gateway",
    badge: "Ordinals/DeFi",
    type: "Bitcoin Wallet",
    iconBg: "from-orange-500/20 to-amber-500/20 border-amber-500/40",
  },
  {
    id: "leather",
    name: "Leather (Hiro)",
    tagline: "Stacks L2, BNS & Bitcoin native signer",
    badge: "Stacks L2",
    type: "Bitcoin Wallet",
    iconBg: "from-yellow-500/20 to-btc/20 border-yellow-500/40",
  },
  {
    id: "okx",
    name: "OKX Web3 DEX",
    tagline: "Multi-chain aggregator with Bitcoin Taproot",
    badge: "Aggregator",
    type: "DEX Gateway",
    iconBg: "from-white/10 to-white/5 border-white/30",
  },
  {
    id: "metamask_snaps",
    name: "MetaMask Snap",
    tagline: "BTC threshold multisig via MetaMask Snap",
    badge: "EVM Snap",
    type: "DEX Gateway",
    iconBg: "from-amber-600/20 to-orange-600/20 border-orange-500/40",
  },
];

const NETWORKS: ("Bitcoin L1" | "ThorChain" | "Stacks L2" | "Babylon")[] = [
  "Bitcoin L1",
  "ThorChain",
  "Stacks L2",
  "Babylon",
];

export function DEXGatewayModal() {
  const { isGatewayOpen, closeGateway, connectWithProvider, openTelemetry } = useDEXGateway();
  const [selectedNetwork, setSelectedNetwork] = useState<"Bitcoin L1" | "ThorChain" | "Stacks L2" | "Babylon">("Bitcoin L1");
  const [manualAddress, setManualAddress] = useState("");
  const [addressError, setAddressError] = useState("");
  const [activeTab, setActiveTab] = useState<"gateways" | "address">("gateways");

  if (!isGatewayOpen) return null;

  const handleManualConnect = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = manualAddress.trim();
    if (!trimmed) {
      setAddressError("Please enter a valid Bitcoin or DEX address");
      return;
    }

    // Basic address sanity check
    const isBtc = /^(bc1|tb1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/i.test(trimmed);
    const isEvm = /^0x[a-fA-F0-9]{40}$/i.test(trimmed);
    const isStacks = /^SP[a-zA-HJ-NP-Z0-9]{28,45}$/i.test(trimmed);

    if (!isBtc && !isEvm && !isStacks && trimmed.length < 10) {
      setAddressError("Unrecognized format. Enter BTC (bc1/1/3), EVM (0x), or Stacks (SP) address.");
      return;
    }

    setAddressError("");
    connectWithProvider("custom_address", trimmed, selectedNetwork);
  };

  const handleSelectGateway = (provider: DexProvider) => {
    connectWithProvider(provider, undefined, selectedNetwork);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="gateway-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-void/85 backdrop-blur-md transition-opacity"
        onClick={closeGateway}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-btc/40 bg-surface shadow-[0_0_60px_-10px_rgb(247_147_26_/_0.35)] holographic-gradient">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-btc/50 bg-btc/20 shadow-[0_0_20px_-4px_rgb(247_147_26_/_0.7)]">
              <Wallet className="h-5 w-5 text-btc" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="gateway-title" className="font-heading text-lg font-bold text-white">
                  DEX Gateway & Wallet Connect
                </h3>
                <Badge variant="gold" size="sm" className="hidden sm:inline-flex">
                  <LiveDot /> Live Gateway
                </Badge>
              </div>
              <p className="font-mono text-xs text-stardust">
                Connect your Bitcoin address or DEX liquidity provider
              </p>
            </div>
          </div>
          <button
            onClick={closeGateway}
            aria-label="Close modal"
            className="rounded-lg p-2 text-stardust transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Network Picker Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-black/40 px-6 py-3">
          <span className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-stardust">
            <Globe className="h-3.5 w-3.5 text-btc" /> Target Network:
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {NETWORKS.map((net) => (
              <button
                key={net}
                type="button"
                onClick={() => setSelectedNetwork(net)}
                className={cn(
                  "rounded-full px-3 py-1 font-mono text-[10px] uppercase tracking-widest transition-all",
                  selectedNetwork === net
                    ? "border border-btc bg-btc/20 text-btc shadow-[0_0_15px_-3px_rgb(247_147_26_/_0.8)]"
                    : "border border-white/10 text-stardust hover:border-white/30 hover:text-white"
                )}
              >
                {net}
              </button>
            ))}
          </div>
        </div>

        {/* Navigation Tabs (Gateways vs Direct Address) */}
        <div className="flex border-b border-white/10 bg-void/50 px-6 pt-3">
          <button
            type="button"
            onClick={() => setActiveTab("gateways")}
            className={cn(
              "flex items-center gap-2 border-b-2 pb-3 font-mono text-xs uppercase tracking-wider transition-all",
              activeTab === "gateways"
                ? "border-btc text-btc font-semibold"
                : "border-transparent text-stardust hover:text-white"
            )}
          >
            <Layers className="h-3.5 w-3.5" />
            DEXs & Signers ({GATEWAY_OPTIONS.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("address")}
            className={cn(
              "ml-6 flex items-center gap-2 border-b-2 pb-3 font-mono text-xs uppercase tracking-wider transition-all",
              activeTab === "address"
                ? "border-btc text-btc font-semibold"
                : "border-transparent text-stardust hover:text-white"
            )}
          >
            <Zap className="h-3.5 w-3.5" />
            Connect by Address
          </button>
        </div>

        {/* Modal Body */}
        <div className="max-h-[50vh] overflow-y-auto p-6">
          {activeTab === "gateways" ? (
            <div className="space-y-4">
              <p className="font-mono text-[11px] text-stardust">
                Select your preferred decentralized exchange router or hardware/browser wallet:
              </p>
              <div className="grid gap-3 sm:grid-cols-2">
                {GATEWAY_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleSelectGateway(opt.id)}
                    className="group relative flex flex-col justify-between rounded-xl border border-white/10 bg-black/40 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-btc/60 hover:bg-white/[0.04] hover:shadow-[0_0_25px_-5px_rgb(247_147_26_/_0.3)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <span
                          className={cn(
                            "flex h-9 w-9 items-center justify-center rounded-lg border bg-gradient-to-br",
                            opt.iconBg
                          )}
                        >
                          <Wallet className="h-4 w-4 text-btc" />
                        </span>
                        <div>
                          <p className="font-heading text-sm font-semibold text-white group-hover:text-btc">
                            {opt.name}
                          </p>
                          <span className="font-mono text-[10px] text-stardust">
                            {opt.type}
                          </span>
                        </div>
                      </div>
                      <Badge variant="btc" size="sm" className="text-[9px] px-2 py-0.5">
                        {opt.badge}
                      </Badge>
                    </div>

                    <p className="mt-3 text-xs leading-relaxed text-stardust line-clamp-2">
                      {opt.tagline}
                    </p>

                    <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-2 text-[10px] font-mono text-stardust">
                      <span className="flex items-center gap-1 text-gold">
                        <ShieldCheck className="h-3 w-3" /> Non-custodial
                      </span>
                      <span className="flex items-center gap-1 text-white group-hover:text-btc">
                        Connect <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="rounded-xl border border-white/10 bg-black/40 p-5">
                <h4 className="font-heading text-sm font-semibold text-white">
                  Paste Direct Public Address
                </h4>
                <p className="mt-1 text-xs text-stardust">
                  Connect by pasting your public Bitcoin address, ThorChain address, or EVM cross-DEX address for read & position tracking.
                </p>

                <form onSubmit={handleManualConnect} className="mt-4 space-y-4">
                  <div>
                    <label htmlFor="btc-address" className="font-mono text-[11px] uppercase tracking-wider text-stardust">
                      Public Wallet or DEX Address:
                    </label>
                    <Input
                      id="btc-address"
                      type="text"
                      value={manualAddress}
                      onChange={(e) => {
                        setManualAddress(e.target.value);
                        setAddressError("");
                      }}
                      placeholder="e.g. bc1p5d76tf... or 0x7F2a... or SP2J..."
                      className="mt-2 font-mono text-xs"
                    />
                    {addressError && (
                      <p className="mt-1.5 font-mono text-xs text-ember">{addressError}</p>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <span className="font-mono text-[10px] text-stardust">Quick demo addresses:</span>
                    <button
                      type="button"
                      onClick={() => setManualAddress("bc1q9d84f8z7k2w09mm8")}
                      className="rounded border border-white/10 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-btc hover:bg-white/10"
                    >
                      Taproot BTC
                    </button>
                    <button
                      type="button"
                      onClick={() => setManualAddress("0x7F2a1059b044Cd9812")}
                      className="rounded border border-white/10 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-gold hover:bg-white/10"
                    >
                      Uniswap BTC
                    </button>
                    <button
                      type="button"
                      onClick={() => setManualAddress("SP2J98ZQ3N6Q84R410")}
                      className="rounded border border-white/10 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-stardust hover:text-white"
                    >
                      Stacks L2
                    </button>
                  </div>

                  <Button type="submit" className="w-full">
                    Connect Address to DEX Gateway <ArrowRight className="h-4 w-4" />
                  </Button>
                </form>
              </div>

              <div className="rounded-lg border border-btc/20 bg-btc/5 p-4 text-xs leading-relaxed text-stardust">
                <span className="font-semibold text-white">🔒 Read & Stacking Security:</span>
                {" "}Pasting an address allows position derivation, APY calculation, and block tracking. Zero private key exposure.
              </div>
            </div>
          )}
        </div>

        {/* Footer info & Telemetry Shortcut */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/10 bg-black/60 px-6 py-4">
          <button
            type="button"
            onClick={() => {
              closeGateway();
              openTelemetry();
            }}
            className="flex items-center gap-2 font-mono text-[11px] text-gold transition-colors hover:underline"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Inspect Backend Telemetry & Take Changes
          </button>

          <div className="flex items-center gap-3 font-mono text-[11px] text-stardust">
            <span className="flex items-center gap-1.5 text-white">
              <CheckCircle2 className="h-3.5 w-3.5 text-btc" />
              Audited 2-of-3 Multisig
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
