import type { InputHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/** Data-entry terminal: bottom-border only, orange glow on focus. */
export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-12 w-full rounded-lg rounded-b-none bg-black/50 px-4 py-2 font-mono text-sm text-white",
        "border-b-2 border-white/20 placeholder:font-body placeholder:text-white/30",
        "transition-all duration-200 focus-visible:border-btc focus-visible:outline-none",
        "focus-visible:shadow-[0_10px_20px_-10px_rgb(247_147_26_/_0.5)]",
        "disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}
