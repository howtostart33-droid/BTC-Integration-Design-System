import { cva, type VariantProps } from "class-variance-authority";
import type { HTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/**
 * The "Block": an elevated surface floating above the void.
 * `solid` = Dark Matter panel, `glass` = translucent floating panel.
 */
export const cardVariants = cva("relative rounded-2xl border transition-all duration-300", {
  variants: {
    variant: {
      solid: "bg-surface border-white/10",
      glass: "bg-black/40 backdrop-blur-lg border-white/10 holographic-gradient",
      subtle: "bg-white/[0.03] border-white/[0.08]",
    },
    interactive: {
      true: "hover:-translate-y-1 hover:border-btc/50 hover:shadow-[0_0_30px_-10px_rgb(247_147_26_/_0.35)]",
      false: "",
    },
  },
  defaultVariants: { variant: "solid", interactive: false },
});

type CardProps = HTMLAttributes<HTMLDivElement> & VariantProps<typeof cardVariants>;

export function Card({ className, variant, interactive, ...props }: CardProps) {
  return (
    <div className={cn(cardVariants({ variant, interactive }), className)} {...props} />
  );
}

export function CardHeader({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-8 pb-4", className)} {...props} />;
}

export function CardTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3
      className={cn("font-heading text-2xl font-semibold leading-tight text-white", className)}
      {...props}
    />
  );
}

export function CardDescription({ className, ...props }: HTMLAttributes<HTMLParagraphElement>) {
  return <p className={cn("text-sm leading-relaxed text-stardust", className)} {...props} />;
}

export function CardContent({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-8 pt-0", className)} {...props} />;
}

export function CardFooter({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-8 pt-0", className)} {...props} />;
}

/** Decorative "selected node" corner accents used on process cards. */
export function CornerAccents({ className }: { className?: string }) {
  return (
    <>
      <span
        aria-hidden
        className={cn(
          "pointer-events-none absolute left-0 top-0 h-6 w-6 rounded-tl-2xl border-l border-t border-btc/60",
          className,
        )}
      />
      <span
        aria-hidden
        className={cn(
          "pointer-events-none absolute bottom-0 right-0 h-6 w-6 rounded-br-2xl border-b border-r border-btc/60",
          className,
        )}
      />
    </>
  );
}
