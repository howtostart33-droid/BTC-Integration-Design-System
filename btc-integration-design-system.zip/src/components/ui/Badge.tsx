import { cva, type VariantProps } from "class-variance-authority";
import type { HTMLAttributes } from "react";
import { cn } from "../../utils/cn";

export const badgeVariants = cva(
  "inline-flex items-center gap-2 rounded-full border font-mono text-[10px] uppercase tracking-widest sm:text-xs",
  {
    variants: {
      variant: {
        default: "border-white/10 bg-white/5 text-stardust",
        btc: "border-btc/40 bg-btc/10 text-btc",
        gold: "border-gold/40 bg-gold/10 text-gold shadow-[0_0_20px_rgb(255_214_0_/_0.15)]",
      },
      size: {
        sm: "px-2.5 py-1",
        md: "px-4 py-1.5",
      },
    },
    defaultVariants: { variant: "default", size: "md" },
  },
);

type BadgeProps = HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>;

export function Badge({ className, variant, size, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant, size }), className)} {...props} />;
}

/** Pulsing "live network" dot — suggests active on-chain state. */
export function LiveDot({ className }: { className?: string }) {
  return (
    <span aria-hidden className={cn("relative flex h-2 w-2", className)}>
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold opacity-75" />
      <span className="relative inline-flex h-2 w-2 rounded-full bg-gold" />
    </span>
  );
}
