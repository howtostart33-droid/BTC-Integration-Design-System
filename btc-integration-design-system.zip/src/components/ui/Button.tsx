import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, AnchorHTMLAttributes } from "react";
import { cn } from "../../utils/cn";

/**
 * Buttons are pill-shaped and emit colored light.
 * Focus rings use the Bitcoin orange token for a consistent, visible a11y state.
 */
export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-full font-body font-semibold tracking-wider uppercase transition-all duration-300 select-none " +
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-btc focus-visible:ring-offset-2 focus-visible:ring-offset-void " +
    "disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary:
          "bg-gradient-to-r from-ember to-btc text-white shadow-[0_0_20px_-5px_rgb(234_88_12_/_0.5)] hover:scale-105 hover:shadow-[0_0_30px_-5px_rgb(247_147_26_/_0.6)]",
        gold: "bg-gradient-to-r from-btc to-gold text-black shadow-[0_0_20px_rgb(255_214_0_/_0.25)] hover:scale-105 hover:shadow-[0_0_30px_rgb(255_214_0_/_0.4)]",
        outline:
          "border-2 border-white/20 text-white hover:border-white hover:bg-white/10",
        ghost: "text-white hover:bg-white/10 hover:text-btc",
        link: "text-btc hover:underline underline-offset-4 px-0 tracking-normal normal-case",
      },
      size: {
        sm: "h-10 min-w-[44px] px-5 text-xs",
        md: "h-12 px-7 text-xs sm:text-sm",
        lg: "h-14 px-9 text-sm",
        icon: "h-11 w-11 min-w-[44px] px-0",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>;

export function Button({ className, variant, size, ...props }: ButtonProps) {
  return (
    <button className={cn(buttonVariants({ variant, size }), className)} {...props} />
  );
}

type ButtonLinkProps = AnchorHTMLAttributes<HTMLAnchorElement> &
  VariantProps<typeof buttonVariants>;

export function ButtonLink({ className, variant, size, ...props }: ButtonLinkProps) {
  return <a className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}
