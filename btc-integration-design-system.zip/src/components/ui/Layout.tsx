import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../../utils/cn";
import { Badge } from "./Badge";

export function Container({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("mx-auto w-full max-w-7xl px-5 sm:px-8", className)} {...props} />;
}

type SectionProps = HTMLAttributes<HTMLElement> & {
  /** Alternating backgrounds replace hard dividers. */
  tone?: "void" | "surface";
};

export function Section({ className, tone = "void", ...props }: SectionProps) {
  return (
    <section
      className={cn(
        "relative overflow-hidden py-20 md:py-24",
        tone === "surface" ? "bg-surface" : "bg-void",
        className,
      )}
      {...props}
    />
  );
}

/** Massive, soft radial light source. Purely decorative ambient depth. */
export function GlowBlob({
  className,
  color = "btc",
}: {
  className?: string;
  color?: "btc" | "ember" | "gold";
}) {
  const tone =
    color === "gold" ? "bg-gold" : color === "ember" ? "bg-ember" : "bg-btc";
  return (
    <div
      aria-hidden
      className={cn(
        "pointer-events-none absolute rounded-full opacity-10 blur-[120px]",
        tone,
        className,
      )}
    />
  );
}

export function SectionHeading({
  eyebrow,
  title,
  accent,
  description,
  align = "center",
  className,
}: {
  eyebrow?: string;
  title: ReactNode;
  accent?: string;
  description?: ReactNode;
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-5",
        align === "center" ? "mx-auto max-w-2xl items-center text-center" : "items-start text-left",
        className,
      )}
    >
      {eyebrow && (
        <Badge variant="btc" size="sm">
          {eyebrow}
        </Badge>
      )}
      <h2 className="font-heading text-3xl font-bold leading-tight tracking-tight text-white md:text-5xl">
        {title} {accent && <span className="text-gradient-btc">{accent}</span>}
      </h2>
      {description && (
        <p className="max-w-xl text-base leading-relaxed text-stardust md:text-lg">
          {description}
        </p>
      )}
    </div>
  );
}
