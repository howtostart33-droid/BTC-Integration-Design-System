import { DEXGatewayProvider } from "./context/DEXGatewayContext";
import { Navbar } from "./components/sections/Navbar";
import { Hero } from "./components/sections/Hero";
import { StatsTicker } from "./components/sections/StatsTicker";
import { Features } from "./components/sections/Features";
import { Process } from "./components/sections/Process";
import { Vaults } from "./components/sections/Vaults";
import { Pricing } from "./components/sections/Pricing";
import { Testimonials } from "./components/sections/Testimonials";
import { CallToAction } from "./components/sections/CallToAction";
import { Footer } from "./components/sections/Footer";
import { DEXGatewayModal } from "./components/gateway/DEXGatewayModal";
import { ProtocolTelemetryModal } from "./components/gateway/ProtocolTelemetryModal";
import { FloatingTelemetryTrigger } from "./components/gateway/FloatingTelemetryTrigger";

export default function App() {
  return (
    <DEXGatewayProvider>
      <div className="min-h-screen bg-void font-body text-white">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-btc focus:px-5 focus:py-2 focus:font-mono focus:text-xs focus:uppercase focus:tracking-widest focus:text-black"
        >
          Skip to content
        </a>
        <Navbar />
        <main id="main">
          <Hero />
          <StatsTicker />
          <Features />
          <Process />
          <Vaults />
          <Pricing />
          <Testimonials />
          <CallToAction />
        </main>
        <Footer />

        {/* Global DEX Gateway Modal for Address & Wallet connections */}
        <DEXGatewayModal />

        {/* Global Protocol Telemetry / Back-Office Monitor Modal */}
        <ProtocolTelemetryModal />

        {/* Floating Quick Dock for easy access to Back-Office stats */}
        <FloatingTelemetryTrigger />
      </div>
    </DEXGatewayProvider>
  );
}
